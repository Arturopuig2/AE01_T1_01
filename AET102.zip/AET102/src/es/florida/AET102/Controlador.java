package es.florida.AET102;

import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador {

	private Modelo modelo;
	private Vista vista;	
	private ActionListener actionListenerBuscar;
	private ActionListener actionListenerReemplazar;
	private String ficheroLectura;
	//private String ficheroEscritura;
	
	public Controlador(Modelo modelo, Vista vista) {
		this.modelo=modelo;
		this.vista=vista;
		control();
	}
		
	public void control() {
		ficheroLectura=modelo.ficheroLectura();
	//	ficheroEscritura=modelo.ficheroEscritura();
		mostrarFichero(ficheroLectura,1);
		
		setActionListenerBuscar(new ActionListener(){
			public void actionPerformed(ActionEvent actionEvent) {
				String textoBuscar=vista.getTextFieldBuscar().getText();
				modelo.buscarTexto(textoBuscar);
		}});
	}


	
	private void mostrarFichero(String fichero, int numeroTextArea) {

		ArrayList<String> arrayLineas=modelo.contenidoFichero(fichero);
		
		for(String linea:arrayLineas) {
			if(numeroTextArea==1)
				vista.getTextAreaOriginal().append(linea+"\n");
				else 
					vista.getTextAreaModificado().append(linea+"\n");				
			}
		}

	public ActionListener getActionListenerBuscar() {
		return actionListenerBuscar;
	}

	public void setActionListenerBuscar(ActionListener actionListenerBuscar) {
		this.actionListenerBuscar = actionListenerBuscar;
	}

	public ActionListener getActionListenerReemplazar() {
		return actionListenerReemplazar;
	}

	public void setActionListenerReemplazar(ActionListener actionListenerReemplazar) {
		this.actionListenerReemplazar = actionListenerReemplazar;
	}
	

	
	
	
	
	
}