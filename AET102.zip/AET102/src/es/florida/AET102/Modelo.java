package es.florida.AET102;

import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
//import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Modelo {
	
	//ATRIBUTOS
	private String fichero_lectura;
	private String fichero_escritura;
	
	
	//CONSTRUCTOR DEL MODELO
	public Modelo() {
		fichero_lectura="Ejemplo_T1_2_Streams_Groucho.txt";
		fichero_escritura="Ejemplo_T1_2_Stream_Groucho_2.txt";	
	}
	
	//ACCESOS GET Y MODIFICADORES SET
	public String getFichero_lectura() {
		return fichero_lectura;
	}
	public void setFichero_lectura(String fichero_lectura) {
		this.fichero_lectura = fichero_lectura;
	}
	public String getFichero_escritura() {
		return fichero_escritura;
	}
	public void setFichero_escritura(String fichero_escritura) {
		this.fichero_escritura = fichero_escritura;
	}


	//MÉTODO que recibe un objeto String y devuelve un Array. Aquí estamos mostrándolo en la pantalla.
public ArrayList<String> contenidoFichero(String fichero){

	//Instanciamos y asignamos espacio en memoria para el OBJETO.
	ArrayList<String> contenidoFichero=new ArrayList<String>();

//LEEMOS el objeto.
	
	//Creamos el OBJETO FILE
	File f=new File(fichero);
	
	try {
		//ABRIMOS los STREAMS
		//Creamos un OBJETO de tipo FILEREADER que lee carácter a carácter
		FileReader fr=new FileReader(f,StandardCharsets.UTF_8);
		//Creamos un OBJETO de tipo BUFFEREDREADER que lee línea a línea.		
		BufferedReader br=new BufferedReader(fr);
		//Lee la línea de br y guárdala en linea. 
		String linea = br.readLine();
		while(linea!=null) {
			contenidoFichero.add(linea);
			linea=br.readLine(); //Lee la siguiente línea.
		}	
		//Cuando salga del bucle cierra los Streams de lectura.	
		br.close();
		fr.close();	
	} 
	catch(Exception e){
		JOptionPane.showMessageDialog(new JFrame(),e.getMessage(),"ERROR", JOptionPane.ERROR_MESSAGE);
	}
	return contenidoFichero;	
		}

//MÉTODOS que devuelve un string con los nombre de los ficheros.
public String ficheroLectura() {
	return fichero_lectura;
	}

public String ficheroEscritura() {
	return fichero_escritura;
}


public int buscarTexto(String textoBuscar) {
	
	File f1=new File(ficheroLectura());
	int contador=0;

	try {
		FileReader fr=new FileReader(f1);
		BufferedReader br=new BufferedReader(fr);
		String linea = br.readLine();
		
		while(linea!=null) {	
			if(linea.indexOf(textoBuscar) > -1) {
				linea = linea.substring(linea.indexOf(
						textoBuscar)+textoBuscar.length(),linea.length());
//			while (linea.indexOf(textoBuscar) > -1) {
//				linea = linea.substring(linea.indexOf(
//						textoBuscar)+textoBuscar.length(),linea.length());	
			      contador++; 
			      System.out.print(contador);
			}
			linea=br.readLine();
		}	
		
		br.close();
		fr.close();	
	} 
	catch(Exception e){
		JOptionPane.showMessageDialog(new JFrame(),e.getMessage(),"ERROR", JOptionPane.ERROR_MESSAGE);
	}
	return contador;	
	}	


public void reemplazarTexto(String textoReemplazar) {
	
}

}







